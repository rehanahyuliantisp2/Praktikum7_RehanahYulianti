<?php

//Buat class
class Dosen_model extends CI_Model{
    //Buat Struktur Data
    public $id, $nama, $nidn, $gender, $tmp_lahir, $tgl_lahir, $pendidikan;

   
    }
?>